*information*

Texture pak.
------------

author		: ken 'kat' beyer
contact		: info@quake3bits.com
url		: http://www.quake3bits.co.uk
copyright	: � Ken Beyer @ Quake3Bits 2004

-------------------------------------------------------------------

INFO
------------
Files are provided 'as is'.

**NONCOMMERCIAL USE**
- Files can be distributed as long as this readme is included.
- Files can be edited and used provided credit is given.


**COMMERCIAL USE**
- This readme file constitutes the licence aggreement.
- This licence allows for single use of enclosed files PER SINGLE PROJECT OR PRESENTATION - if further use is required either additional licences need to be purchased or contact the author to discuss your specific projects requirements.
- Distribution is NOT permitted without prior written consent.
- Editing or changes made to the enclosed files is not permitted without prior written consent.

-------------------------------------------------------------------